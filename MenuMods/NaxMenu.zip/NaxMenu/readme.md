--change log--

[+] better ui

[+] alot

F6 TO OPEN MENU
